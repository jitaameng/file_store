# 问题记录
## 如何安装？
* 我已经安装了 mmdetection 等等，但是还是需要在文件夹下输入命令 ```pip install -v -e .  # or "python setup.py develop"```
* 我直接跑的时候，有个叫做 pycocotools 的包不能用，我把它删掉了，然后再把 mmpycocotools 也删掉了；再重新 ```pip install mmpycocotools``` 就可以正常跑起来了
## 数据集位置
* scrfd 的数据集好像是自己有单独的标注，需要在 https://drive.google.com/file/d/1UW3KoApOhusyqSHX96yEDRYiNkd3Iv3Z/view?usp=sharing 这个链接里面下载，然后按照一定的格式进行排版
## config 文件初次修改
* 第一次跑我修改了 scrfd_2.5g.py里面的文件路径，其他基本上都没有改
* 因为我的 mmcv 版本比较高，所以我把 /home/wangcy/wcy/insightface/detection/scrfd/mmdet/__init__.py 这个文件下 19 行的 mmcv 版本最高限制改成了 1.6.0